package com.lening.test2;

public class Demo2 {
    public static void main(String[] args) {
        //声明数组的同时完成对数组的赋值
        String[] names = {"张三","李四","王五","赵六","田七"};
        int[] ages = new int[]{20, 30, 40, 50, 60};
    }
}
